from __future__ import print_function
import requests
import zipfile
import warnings
from sys import stdout
from os import makedirs
from os.path import dirname
from os.path import exists
import xbmcvfs, xbmc, xbmcaddon

class GoogleDriveDownloader:
    """
    Minimal class to download shared files from Google Drive.
    """

    CHUNK_SIZE = 32768
    DOWNLOAD_URL = 'https://docs.google.com/uc?export=download'

    @staticmethod
    def download_file_from_google_drive(file_id, dest_path, resume=False, dim=0):

        destination_directory = dirname(dest_path)
        if not exists(destination_directory):
            makedirs(destination_directory)

        if not exists(dest_path) or resume:

            session = requests.Session()

            print('Downloading {} into {}... '.format(file_id, dest_path), end='')
            stdout.flush()
            
            if exists(dest_path):
                resume_byte_pos = xbmcvfs.Stat(dest_path).st_size()
                resume_header = {'Range': 'bytes=%d-' % resume_byte_pos}
            else:
                resume_header = {}
            
            response = session.get(GoogleDriveDownloader.DOWNLOAD_URL, params={'id': file_id}, headers=resume_header, stream=True)
            token = GoogleDriveDownloader._get_confirm_token(response)
            if token:
                params = {'id': file_id, 'confirm': token}
                response = session.get(GoogleDriveDownloader.DOWNLOAD_URL, headers=resume_header, params=params, stream=True)
            
            #total_size = int(response.headers.get('content-length', 0))
            total_size = dim
            GoogleDriveDownloader._save_response_content(response, dest_path, total_size, file_id)


    @staticmethod
    def _get_confirm_token(response):
        for key, value in response.cookies.items():
            if key.startswith('download_warning'):
                return value
        return None

    @staticmethod
    def _save_response_content(response, destination, total_size, file_id):
        
        Addon = xbmcaddon.Addon('plugin.video.kodilivetv')
        icon = Addon.getAddonInfo('icon')
        localizedString = Addon.getLocalizedString
        
        Namefile = destination.replace('\\','/')
        Namefile = Namefile.split("/")[-1]
        Namefile = Namefile.replace("_"," ")
        ext = Namefile.split(".")[-1]
        Namefile = Namefile.replace( "." + ext , "" )
        
        file_nameS = destination + ".stopped"
        
        if xbmcvfs.exists(destination):
            if destination.find("smb://")>-1
                f = xbmcvfs.File(destination, 'wb')
            else:
                f = open(destination, 'ab')
        else:
            ow = 'wb'            
            file_name = destination + ".resume"
            fh = xbmcvfs.File(file_name, "wb")
            fh.write(str(total_size) + "\r\n" + "https://drive.google.com/file/d/" + file_id + "/view")
            fh.close()
            xbmc.executebuiltin("XBMC.Container.Refresh()")
            xbmc.sleep(300)
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('Download file: ', Namefile.encode('utf-8'), 4100, icon))
            f = xbmcvfs.File(destination, 'wb')
                    
        for chunk in response.iter_content(GoogleDriveDownloader.CHUNK_SIZE):
            if chunk:  # filter out keep-alive new chunks
                if xbmcvfs.exists(file_nameS):
                    break
                f.write(chunk)

        if not xbmcvfs.exists(file_nameS):
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(Namefile.encode('utf-8'), localizedString(10209).encode('utf-8'), 3500, icon))
            
            if xbmcvfs.exists(destination + ".resume"):
                xbmcvfs.delete(destination + ".resume")
            f.close()
