# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Conector para speedvideo
# by be4t5
# fix by Vania
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
# ------------------------------------------------------------

import base64
import re

from core import logger
from core import scrapertools

headers = [['User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:54.0) Gecko/20100101 Firefox/54.0']]

def test_video_exists(page_url):
    logger.info("(page_url='%s')" % page_url)

    return True, ""


def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    logger.info("url=" + page_url)
    video_urls = []
    
    headers.append(['Referer', page_url])

    html = scrapertools.cachePage(page_url, headers=headers)

    # Decrypt link base64 // python version of speedvideo's base64_decode() [javascript]

    a = re.compile('var\s+linkfile *= *"(.+?)"').findall(html)[0]
    b = re.compile('var\s+linkfile *= *base64_decode\(.+?\s+(.+?)\)').findall(html)[0]
    c = re.compile('var\s+%s *= *(\d*)' % b).findall(html)[0]
    
    stream_url = a[:int(c)] + a[(int(c) + 10):]
    media_url = base64.b64decode(stream_url)
    
    video_urls.append(["." + media_url.rsplit('.', 1)[1] + ' [speedvideo]', media_url])

    return video_urls

