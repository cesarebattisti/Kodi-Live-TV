# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# streamondemand-pureita - XBMC Plugin
# Connettore per ok.ru
# http://www.mimediacenter.info/foro/viewtopic.php?f=36&t=7808
# by DrZ3r0
# ------------------------------------------------------------

import re

from core import httptools
from core import logger
from core import scrapertools


def test_video_exists(page_url):
    logger.info("(page_url='%s')" % page_url)
    
    data = httptools.downloadpage(page_url).data
    if "copyrightsRestricted" in data:
        return False, "[Okru] El archivo ha sido eliminado por violación del copyright"
    elif "notFound" in data:
        return False, "[Okru] El archivo no existe o ha sido eliminado"

    return True, ""


def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    
    video_urls = []
    
    if page_url.find("/live/")>0:
        data = httptools.downloadpage(page_url).data
        data = scrapertools.decodeHtmlentities(data).replace('\\', '')
        #import xbmc
        
        for url in re.findall(r'"hlsMasterPlaylistUrl":"([^"]+)', data, re.DOTALL):
            
            url = url.replace("%3B", ";").replace("u0026", "&").replace("?p", "")
            #xbmc.log('***********URL : ' + url, xbmc.LOGNOTICE )
        
        video_urls.append(["hd [okru]", url])
    else:
        page_url = page_url.replace("/video/","/videoembed/")
        logger.info("url=" + page_url)
        
        data = httptools.downloadpage(page_url).data
        fnd = "sd"
        option = [ ]
        q = [ ]
        
        import xbmcgui, sys
        
        if data.find("name\&quot;:\&quot;ultra\&quot;")>0:
            option.append(" Select Video Source [2160p] ")
            q.append("ultra")    
        if data.find("name\&quot;:\&quot;quad\&quot;")>0:
            option.append(" Select Video Source [1440p] ")
            q.append("quad")
        if data.find("name\&quot;:\&quot;full\&quot;")>0:
            option.append(" Select Video Source [1080p] ")
            q.append("full")
        if data.find("name\&quot;:\&quot;hd\&quot;")>0:
            option.append(" Select Video Source [720p] ")
            q.append("hd")
        if data.find("name\&quot;:\&quot;sd\&quot;")>0:
            option.append(" Select Video Source [480p] ")
            q.append("sd")
        if data.find("name\&quot;:\&quot;low\&quot;")>0:
            option.append(" Select Video Source [360p] ")
            q.append("low")    
        
        if data.find("name\&quot;:\&quot;mobile\&quot;")>0 and len(q) == 0:
            option.append(" Select Video Source [In progress] ")
            q.append("mobile")
        
        if len(q) == 0:
            sys.exit()
        
        index = xbmcgui.Dialog().select("Chose Video Quality", list=option)
        
        if index > -1:
            fnd = q[index]
        else:
            sys.exit()    
        
        data = scrapertools.decodeHtmlentities(data).replace('\\', '')
        logger.info(data)
        # URL del vídeo
        
        for url in re.findall(r'\{"name":"' + fnd + '","url":"([^"]+)"', data, re.DOTALL):
            url = url.replace("%3B", ";").replace("u0026", "&")
            video_urls.append([fnd + " [okru]", url])

    return video_urls


# Encuentra vídeos del servidor en el texto pasado
def find_videos(text):
    encontrados = set()
    devuelve = []

    patronvideos = '//(?:www.)?ok.../(?:videoembed|video)/(\d+)'
    logger.info("#" + patronvideos + "#")

    matches = re.compile(patronvideos, re.DOTALL).findall(text)

    for media_id in matches:
        titulo = "[okru]"
        url = 'http://ok.ru/videoembed/%s' % media_id
        if url not in encontrados:
            logger.info("url=" + url)
            devuelve.append([titulo, url, 'okru'])
            encontrados.add(url)
        else:
            logger.info("url duplicada=" + url)

    return devuelve
